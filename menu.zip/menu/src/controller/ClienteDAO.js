// npm i @react-native-async-storage/async-storage
import AsyncStorage from '@react-native-async-storage/async-storage';
import Cliente from '../model/Cliente'

module.exports = class ClienteDAO{

    async gravar(cliente) {
        try {
            await AsyncStorage.setItem(cliente.nome, cliente.idade)
            return("Sucesso.")
        }
        catch (erro) {
            throw ("Erro ao gravar: "+ erro)
        }
    }
    async limpar() {
        try {
            await AsyncStorage.clear()
            return("Sucesso.")
        }
        catch (erro) {
            throw ("Erro ao limpar: "+ erro)
        }
    }

    async listar() {
        try {
            let i=0
            const chaves = await AsyncStorage.getAllKeys();
            const vetor = new Array()
            for (i = 0; i < chaves.length; i++){
                let obj = new Cliente()
                obj.nome = chaves[i]
                obj.idade = await AsyncStorage.getItem(chaves[i])
                vetor.push(obj)
            }
            return vetor
        }
        catch (erro) {
            throw ("Erro ao listar: "+ erro)
        }
    }


}