module.exports = class Cliente{
    #nome
    #idade
    constructor() {
        this.#nome = ''
        this.#idade=0
    }

    set nome(n) {
        this.#nome=n
    }
    get nome() {
        return this.#nome
    }
    set idade(i) {
        this.#idade=i
    }
    get idade() {
        return this.#idade
    }
}
