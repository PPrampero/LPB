import { StatusBar } from 'expo-status-bar';
import { Button, StyleSheet, Text, TextInput, View } from 'react-native';
import { useState } from 'react';
import Cliente from '../src/model/Cliente'
import ClienteDAO from '../src/controller/ClienteDAO'


export default function Tela1() {
  const [nome, setNome] = useState("")
  const [idade, setIdade] = useState(0)
  const [saida, setSaida] = useState("")

  async function gravar() {
    try {
      if (nome.length < 1 || idade <= 0)
        throw "Campos inválidos."
      else {
        let obj = new Cliente()
        obj.nome = nome
        obj.idade = idade
        let dao = new ClienteDAO()
        let s = await dao.gravar(obj)
        setSaida(s)
      }
    }
    catch (erro) {
      setSaida(erro)
    }
  }


  return (
    <View style={styles.container}>
      <View style={styles.linha}>
        <Text style={styles.texto}>Nome</Text>
        <TextInput style={styles.entrada} value={nome} onChangeText={setNome} />
      </View>
      <Text> </Text>
      <View style={styles.linha}>
        <Text style={styles.texto} >Idade</Text>
        <TextInput style={styles.entrada} value={idade} onChangeText={setIdade} />
      </View>
      <Button title="Gravar" onPress={gravar} />
      <Text style={styles.saida} >{saida}</Text>
      <StatusBar style="auto" />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'cyan',
    alignItems: 'center',
    justifyContent: 'center',
  },
  linha: {
    flexDirection: 'row',
  },
  texto: {
    fontSize: 30,
  },
  entrada: {
    fontSize: 30,
    borderWidth: 1,
    backgroundColor: 'white',
  },
  saida: {
    fontSize: 50,
    color: 'blue',
  },
});
