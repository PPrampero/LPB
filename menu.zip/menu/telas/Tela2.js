import { StatusBar } from 'expo-status-bar';
import { TouchableOpacity,FlatList,Button, StyleSheet, Text, TextInput, View } from 'react-native';
import { useEffect,useState } from 'react';
import Cliente from '../src/model/Cliente'
import ClienteDAO from '../src/controller/ClienteDAO'


export default function Tela1() {
  const [saida, setSaida] = useState("")
  const [listaDados, setListaDados] = useState("")

  async function listar() {
    try {
      let dao = new ClienteDAO()
      let v = await dao.listar()
      let s = ""
 //     for (i = 0; i < v.length; i++) {
  //      s = s + v[i].nome + " " + v[i].idade + "\n"
 //     }
      //    setSaida(s)
      setListaDados(v)
    }
    catch (erro) {
      setSaida(erro)
    }
  }

  //roda automaticamente
  useEffect(() => {
   listar()
  }, [])
  

  return (
    <View style={styles.container}>
      <Button title="Listar" onPress={listar} />
      <Text>Pessoas cadastradas</Text>
      <FlatList
        data={listaDados}
        renderItem={({ item }) =>
          <TouchableOpacity >
            <Text style={styles.item} >
              {item.nome}      {item.idade}
            </Text>
          </TouchableOpacity>
        }
      />

      <Text>{saida}</Text>

      <StatusBar style="auto" />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'pink',
    alignItems: 'center',
    justifyContent: 'center',
  },
});
